package be.kuleuven.foodrestservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FoodRestServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FoodRestServiceApplication.class, args);
	}

}
